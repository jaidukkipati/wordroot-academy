---
name: 🐛 Bug Report
about: Something isn't working correctly
title: '[BUG] '
labels: bug
assignees: ''
---

## 🐛 Bug Description
<!-- A clear, concise description of the bug -->

## Steps to Reproduce
1. Go to '...'
2. Click on '...'
3. See error

## Expected Behaviour
<!-- What should have happened? -->

## Actual Behaviour
<!-- What actually happened? -->

## Screenshots
<!-- If applicable, add screenshots -->

## Environment
- App Version: <!-- e.g. v1.0.0 — check bottom-right corner of the app -->
- Browser: <!-- e.g. Chrome 120, Safari 17, Firefox 121 -->
- Device: <!-- e.g. MacBook, iPhone 15, Windows laptop -->
- Role affected: <!-- Student / Parent / Both -->

## Console Errors
<!-- Open browser DevTools (F12), go to Console tab, paste any red errors here -->
```
paste errors here
```

## Additional Context
<!-- Any other information that might help -->

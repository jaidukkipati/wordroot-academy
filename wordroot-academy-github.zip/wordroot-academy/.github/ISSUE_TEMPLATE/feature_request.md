---
name: ✨ Feature Request
about: Suggest a new feature or improvement
title: '[FEATURE] '
labels: enhancement
assignees: ''
---

## ✨ Feature Description
<!-- A clear description of the feature you'd like -->

## Problem It Solves
<!-- What problem does this feature address? -->
<!-- e.g. "My daughter forgets words she studied last week — I'd like a spaced repetition review system" -->

## Proposed Solution
<!-- How do you imagine this working? -->

## Who Benefits
- [ ] Student (learning experience)
- [ ] Parent (monitoring / dashboard)
- [ ] Both

## Priority
- [ ] 🔴 High — blocks important use case
- [ ] 🟡 Medium — would significantly improve the app
- [ ] 🟢 Low — nice to have

## Additional Context
<!-- Any other information, mockups, or examples -->
